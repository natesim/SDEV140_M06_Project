#importing the packages
import tkinter as tk
from tkinter import *
import time
from tkinter import messagebox

#creating the main window
window=tk.Tk()
window.minsize(700,500)

#main window
window.title("Kirby's Pizza")

#Time/Date Stamp
localtime=time.asctime(time.localtime(time.time()))
current_time=Label(window,text=localtime,fg="blue",font=("default",12))
current_time.place(x=480,y=455)

#Main Title
label_mainTitle=tk.Label(window,text="Welcome to Kirby's Pizza",fg="blue", font=("Arial",30))
label_mainTitle.place(x=120,y=20)

'''
C = Canvas(window, bg="blue", height=150, width=200)
filename = PhotoImage(file = "kirbyPizza.png")
background_label = Label(window, image=filename)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
C.pack()
'''

'''
mainf1=Frame(window,height=700,width=500)
logo=PhotoImage(file="kirbyPizza.png")
l=Label(mainf1,image=logo)
l.place(x=0,y=0, width= 600, height= 450)
mainf1.pack(fill=BOTH,expand=YES)
'''

'''
PhotoImage(file="kirbyPizza.png")
photo = PhotoImage(image)
label = Label(window, image = photo)
label.bind('<Configure>', resize_image)
label.pack(fill=BOTH, expand = YES)
'''

'''
c=Canvas(window,height=618,width=800)
c.pack(fill=BOTH, expand=1)
logo1=PhotoImage(file="kirbyPizza.png")
c.create_image(683,309,image=logo1)
c.create_rectangle(50,100,700,450,fill="#d3ede6",outline="white",width=6)
'''

#Labels
label_1=tk.Label(window,text="Cheese",font=("Arial",15))
label_1.place(x=150,y=260)

label_2=tk.Label(window,text="Pepperoni",font=("Arial",15))
label_2.place(x=285,y=260)

label_3=tk.Label(window,text="Sausage",font=("Arial",15))
label_3.place(x=450,y=260)

text_field_1=tk.Entry(window,font=("Arial",15))
text_field_1.place(x=155,y=300, width= 60, height= 25)

text_field_2=tk.Entry(window,font=("Arial",15))
text_field_2.place(x=300,y=300, width= 60, height= 25)

text_field_3=tk.Entry(window,font=("Arial",15))
text_field_3.place(x=460,y=300, width= 60, height= 25)

#Add to Cart button for application
button_2 =tk.Button(window,text="Add to Cart",command="",font=("Arial",15))
button_2.place(x=270,y=350)

#Exit button for application
button_3 =tk.Button(window,text="Exit",command=window.destroy, fg="red", font=("Arial",15))
button_3.place(x=590,y=400, width= 80, height= 45)

#starting the main window
window.mainloop()