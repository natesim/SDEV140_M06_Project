from tkinter import *
import time
from tkinter import messagebox

'''
This is a simple pizza ordering application.  Users will launch the application, click through the first screen,
then add whatever products they want.  User will then click total to find out how much they will pay.

User will click Pay button to initiate payment.  However, for this use case, the Pay button takes you back
to the main screen since the Pay screen is not developed.
'''

class kirbysPizza:
    cartlist=[]
    amount=0
#--  page 1------
    def main(self):
        try:
            self.mainWindow.destroy()
            self.mainWindow=Tk()
        except:
            try:
                self.mainWindow=Tk()
            except:
                pass
        
#This is the main screen where User will land.

        self.mainWindow.geometry("1366x768")
        self.mainWindow.title("Kirby's Online Pizza Ordering")
        self.mainWindow.iconbitmap('p.ico')       
        self.mainf1=Frame(self.mainWindow,height=150,width=1366)
        self.l=Label(self.mainWindow,text="Welcome to Kirby's Pizza",fg="blue", font=("Arial",50))
        self.l.place(x=320,y=40)
        self.mainf1.pack(fill=BOTH,expand=1)
        self.mainf2=Frame(self.mainWindow,height=618,width=1366)
        self.c=Canvas(self.mainf2,height=618,width=1366)
        self.c.pack()
        self.back2=PhotoImage(file="pepsiBottle.png")
        self.c.create_image(283,184,image=self.back2)
        self.back1=PhotoImage(file="kirbyPizza.png")
        self.c.create_image(683,184,image=self.back1)
        self.back3=PhotoImage(file="pepsiBottle.png")
        self.c.create_image(1083,184,image=self.back3)
        self.lab=Button(self.mainf2,text= "Click Here to Proceed",command=lambda:self.mainOrdermainWindoween(),cursor="hand2", bd=10 ,font=("black",30, 'bold'),fg="white",bg="#0b1335")
        self.lab.place(x=450,y=350)
        self.mainf2.pack(fill=BOTH,expand=1)

        #Time/Date Stamp - Purpose was only for practice at pulling date/time.  I feel it will be useful in future.
        localtime=time.asctime(time.localtime(time.time()))
        current_time=Label(self.mainf2,text=localtime,fg="blue",font=("default",16))
        current_time.place(x=570,y=500)

        #Exit Button - This will exit the application
        self.lab=Button(self.mainf2,text= "Exit",command=lambda:self.mainWindow.destroy(),cursor="hand2", bd=10 ,font=("red",30, 'bold'),fg="red",bg="#0b1335")
        self.lab.place(x=1150,y=450)
        self.mainf2.pack(fill=BOTH,expand=1)

        self.mainWindow.mainloop()

#This is the main screen where user will interact with the products they want to order.

#--  page 2------
    def mainOrdermainWindoween(self):
        self.mainWindow.destroy()
        self.mainWindow = Tk()
        self.mainWindow.title("Kirby's Pizza")
        self.mainWindow.geometry("1366x768")

        self.admainf1=Frame(self.mainWindow,bg="#b8c2f2",height=150,width=1366)
        self.admainf1.pack(side=TOP,fill=BOTH)
        self.c=Canvas(self.admainf1,height=150,bg="#778ae6",width=1366)
        self.c.pack()
        self.l=Label(self.mainWindow,text="Welcome to Kirby's Pizza",fg="blue", bg="#778ae6", font=("Arial",50))
        self.l.place(x=320,y=20)
        self.localtime=time.asctime(time.localtime(time.time()))
        self.c.create_text(900,50,text=self.localtime,fill="white",font=("default",16))
        self.c.create_text(683,125,font=( 'Black' ,25, 'bold','underline' ),text="Online Ordering System")
        self.out=Button(self.admainf1,text="Return to Main Screen",bg="#0b1335",cursor="hand2",command=lambda:self.main(),fg="white",bd=5,font=("default",16,'bold'))
        self.out.place(x=1100,y=25)

        def Calculations(self):
            self.dropdownPizza1=self.vpizza1.get()
            if self.dropdownPizza1=="Medium":
                self.pizza1=float(self.Cheese.get())*9
            elif self.dropdownPizza1=="Large":
                self.pizza1=float(self.Cheese.get())*11
            else:
                self.pizza1=float(self.Cheese.get())*7
            self.dropdownPizza2=self.vpizza2.get()
            if self.dropdownPizza2=="Medium":
                self.pizza2= float(self.Sausage.get())*9
            elif self.dropdownPizza2=="Large":
                self.pizza2= float(self.Sausage.get())*11
            else:
                self.pizza2= float(self.Sausage.get())*7
            self.dropdownPizza3=self.vpizza3.get()
            if self.dropdownPizza3=="Medium":
                self.pizza3= float(self.Pepperoni.get())*9
            elif self.dropdownPizza3=="Large":
                self.pizza3= float(self.Pepperoni.get())*11
            else:
                self.pizza3= float(self.Pepperoni.get())*7
            self.drinkPepsi= float(self.Pepsi.get())*2
            self.drinkDietPepsi= float(self.Diet_Pepsi.get())*2
            self.drinkWater= float(self.Water.get())*2
            
            self.costofmeal = "$" + str('%.2f'% (self.pizza1+self.pizza2+self.pizza3+self.drinkPepsi+self.drinkDietPepsi+self.drinkWater))
            self.PayTax=((self.pizza1+self.pizza2+self.pizza3+self.drinkPepsi+self.drinkDietPepsi+self.drinkWater)*.08)
            self.Totalcost=(self.pizza1+self.pizza2+self.pizza3+self.drinkPepsi+self.drinkDietPepsi+self.drinkWater)
            self.Ser_Charge=((self.pizza1+self.pizza2+self.pizza3+self.drinkPepsi+self.drinkDietPepsi+self.drinkWater)/5)
            self.Service="$"+str('%.2f'% self.Ser_Charge)
            self.OverAllCost="$"+str('%.2f'%(self.PayTax + self.Totalcost + self.Ser_Charge))
            self.PaidTax="$"+str('%.2f'% self.PayTax)
            self.money=int(self.PayTax + self.Totalcost + self.Ser_Charge)
            self.Service_Charge.set(self.Service)
            self.cost.set(self.costofmeal)
            self.Tax.set(self.PaidTax)
            self.Total.set(self.OverAllCost) 


        #set default vaults
        def setDefaultValues(self):
            self.Cheese.set("0")
            self.Sausage.set("0")
            self.Pepperoni.set("0")
            self.Pepsi.set("0")
            self.Diet_Pepsi.set("0")
            self.Water.set("0")
            self.Total.set("0")
            self.Service_Charge.set("0")
            self.Tax.set("0")
            self.cost.set("0")
            self.order.set("0")
            self.Cutomer_name.set("")
            self.cusmob.set("")
            self.vpizza1.set("Medium")
            self.vpizza2.set("Medium")
            self.vpizza3.set("Medium")   
        


        self.admainf2 = Frame(self.mainWindow,width =1366,bg="#f2e8b8",height=618,relief=SUNKEN)
        self.admainf2.pack(side=BOTTOM,fill=BOTH,expand=1)
        self.Cheese= StringVar()
        self.Pepperoni = StringVar()
        self.Sausage = StringVar()
        self.Pepsi = StringVar()
        self.Diet_Pepsi = StringVar()
        self.Water = StringVar()
        self.Total = StringVar()
        self.Service_Charge= StringVar()
        self.Tax = StringVar()
        self.cost = StringVar()
        self.order=StringVar()
        self.Cutomer_name =StringVar()
        self.cusmob = StringVar()
        self.vpizza1=StringVar()
        self.vpizza2=StringVar()
        self.vpizza3=StringVar()
        self.vdrinkPepsi=StringVar()
        self.vdrinkDietPepsi=StringVar()
        setDefaultValues(self)
        self.l=["Small", "Medium","Large"]

##Begins fields on mainWindow
        #Pizza
        self.non=Label(self.admainf2,pady=2,text=(" "),font=( ' Black' ,20),bg="#f2e8b8",bd=10,anchor='w')
        self.non.grid(row=3,column=1)
        self.lbl1 = Label(self.admainf2,pady=2, font=( ' Black' ,20, 'bold','underline' ),bg="#f2e8b8",text="Pizza",bd=10,anchor='w')
        self.lbl1.place(x=80,y=110)
        self.lbl11 = Label(self.admainf2,pady=2, font=( ' Black' ,16,'underline' ),width=6,bg="#f2e8b8",text="Items",bd=6,anchor='w')
        self.lbl11.grid(row=4,column=0)
        self.lbl12 = Label(self.admainf2,pady=2, font=( ' Black' ,16,'underline' ),width=7,bg="#f2e8b8",text="Size",bd=6,anchor='w')
        self.lbl12.grid(row=4,column=1)
        self.lbl13 = Label(self.admainf2,pady=2, font=( ' Black' ,16,'underline' ),width=8,bg="#f2e8b8",text="Quantity",bd=6,anchor='w')
        self.lbl13.grid(row=4,column=2,padx=4)

        self.lblcheese= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="     Cheese:", justify="right", bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblcheese.grid(row=5,column=0)
        self.opcheese=OptionMenu(self.admainf2,self.vpizza1,*self.l)
        self.opcheese.config(width=6)
        self.opcheese.grid(row=5,column=1)
        self.txtcheese= Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Cheese , bd=6,width=4,bg="white" ,justify='right')
        self.txtcheese.grid(row=5,column=2)

        self.lblpepp = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="Pepperoni:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblpepp.grid(row=6,column=0)
        self.oppepp=OptionMenu(self.admainf2,self.vpizza2,*self.l)
        self.oppepp.config(width=6)
        self.oppepp.grid(row=6,column=1)
        self.txtpepp = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Pepperoni , bd=6,width=4,bg="white" ,justify='right')
        self.txtpepp.grid(row=6,column=2)

        self.lblsaus= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="   Sausage:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblsaus.grid(row=7,column=0)
        self.opsaus=OptionMenu(self.admainf2,self.vpizza3,*self.l)
        self.opsaus.config(width=6)
        self.opsaus.grid(row=7,column=1)
        self.txtsaus= Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Sausage ,bd=6,width=4,bg="white" ,justify='right')
        self.txtsaus.grid(row=7,column=2)



        #Drinks
        self.non=Label(self.admainf2,pady=2,text=(" "),font=( ' Black' ,20),bg="#f2e8b8",bd=10,anchor='w')
        self.non.grid(row=3,column=4)
        self.lbl4 = Label(self.admainf2,pady=2, font=( ' Black' ,20, 'bold','underline' ),bg="#f2e8b8",text="Beverages",bd=10,anchor='w')
        self.lbl4.place(x=400,y=110)
        self.lbl41 = Label(self.admainf2,pady=2, font=( ' Black' ,16,'underline' ),width=6,bg="#f2e8b8",text="Items",bd=6,anchor='w')
        self.lbl41.grid(row=4,column=4)
        self.lbl43 = Label(self.admainf2,pady=2, font=( ' Black' ,16,'underline' ),width=8,bg="#f2e8b8",text="Quantity",bd=6,anchor='w')
        self.lbl43.grid(row=4,column=5)

        self.lblpepsi= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="       Pepsi:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblpepsi.grid(row=5,column=4)
        self.txtpepsi= Entry(self.admainf2,width=4,font=('ariel' ,16,'bold'), textvariable=self.Pepsi , bd=6,bg="white" ,justify='right')
        self.txtpepsi.grid(row=5,column=5)

        self.lbldietPepsi = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="Diet Pepsi:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lbldietPepsi.grid(row=6,column=4)
        self.txtdietPepsi = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Diet_Pepsi , bd=6,width=4,bg="white" ,justify='right')
        self.txtdietPepsi.grid(row=6,column=5)

        self.lblwater= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="       Water:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblwater.grid(row=7,column=4)
        self.txtwater= Entry(self.admainf2,width=4,font=('ariel' ,16,'bold'), textvariable=self.Water , bd=6,bg="white" ,justify='right')
        self.txtwater.grid(row=7,column=5)

        # customer
        self.non=Label(self.admainf2,pady=2,text=(" "),font=( ' Black' ,20),bg="#f2e8b8",bd=10,anchor='w')
        self.non.grid(row=0,column=8)
        self.lbl6 = Label(self.admainf2,pady=2, font=( ' Black' ,22, 'bold','underline' ),bg="#f2e8b8",text="Customer Information",bd=10,anchor='w')
        self.lbl6.place(x=720,y=0)
        
        self.lblnam= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),width=10,text="          Name:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblnam.grid(row=1,column=7)
        self.txtnam= Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Cutomer_name , bd=6,width=14,bg="white" ,justify='left')
        self.txtnam.grid(row=1,column=8)


        self.lblContactNumber = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="Contact No:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblContactNumber.grid(row=2,column=7)
        self.txtContactNumber = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.cusmob,width=14,bd=6,bg="white" ,justify='left')
        self.txtContactNumber.grid(row=2,column=8)

    #This screen is for listing out prices of products.  
        def price(self):
                self.priceScreen = Tk()
                self.priceScreen.geometry("600x768+0+0")
                self.priceScreen.title("Price List")
                self.lblinfo = Label(self.priceScreen, font=('aria', 18, 'bold'), text="ITEM", fg="black", bd=5)
                self.lblinfo.grid(row=0, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15,'bold'), text="Choose a Pizza", fg="black", anchor=W)
                self.lblinfo.grid(row=1, column=1)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15), text="(Small/Medium/Large/)", fg="black", anchor=W)
                self.lblinfo.grid(row=1, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 18, 'bold'), text="PRICE", fg="black", anchor=W)
                self.lblinfo.grid(row=0, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Cheese", fg="blue", anchor=W)
                self.lblinfo.grid(row=2, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$7.00/$9.00/$11.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=2, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Sausage", fg="blue", anchor=W)
                self.lblinfo.grid(row=3, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$7.00/$9.00/$11.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=3, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$7.00/$9.00/$11.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=4, column=2)            
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Pepperoni", fg="blue", anchor=W)
                self.lblinfo.grid(row=4, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Beverages", fg="black", anchor=W)
                self.lblinfo.grid(row=15, column=1)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Pepsi", fg="blue", anchor=W)
                self.lblinfo.grid(row=16, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$2.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=16, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Diet Pepsi", fg="blue", anchor=W)
                self.lblinfo.grid(row=17, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$2.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=17, column=2)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="Water", fg="blue", anchor=W)
                self.lblinfo.grid(row=18, column=0)
                self.lblinfo = Label(self.priceScreen, font=('aria', 15, 'bold'), text="$2.00", fg="blue", anchor=W)
                self.lblinfo.grid(row=18, column=2)
                self.priceScreen.mainloop()

        #This resets all fields with Reset Button
        def reset(self):
            self.Cheese.set("0")
            self.Sausage.set("0")
            self.Pepperoni.set("0")
            self.Pepsi.set("0")
            self.Diet_Pepsi.set("0")
            self.Water.set("0")
            self.Total.set("0")
            self.Service_Charge.set("0")
            self.Tax.set("0")
            self.cost.set("0")
            self.order.set("0")
            self.Cutomer_name.set("")
            self.cusmob.set("")
            self.vpizza1.set("Medium")
            self.vpizza2.set("Medium")
            self.vpizza3.set("Medium")


        #total Charge

        #This section houses the labels and fields for showing what the costs are

        self.non=Label(self.admainf2,pady=2,text=(" "),font=( ' Black' ,20),bg="#f2e8b8",bd=10,anchor='w')
        self.non.grid(row=3,column=8)
        self.lbl5 = Label(self.admainf2,pady=2, font=( ' Black' ,22, 'bold','underline' ),bg="#f2e8b8",text="Calculate Payment",bd=10,anchor='w')
        self.lbl5.place(x=750,y=140)

        self.non=Label(self.admainf2,pady=2,text=(" "),font=( ' Black' ,20),width=5,bg="#f2e8b8",bd=10,anchor='w')
        self.non.grid(row=4,column=6)
        self.lblord= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),width=10,text="       Order No:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblord.grid(row=4,column=7)
        self.txtord= Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.order , bd=6,width=14,bg="light grey" ,justify='right')
        self.txtord.grid(row=4,column=8)

        self.lblco = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="          Subtotal:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblco.grid(row=5,column=7)
        self.txtco = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.cost,width=14,bd=6,bg="light grey" ,justify='right')
        self.txtco.grid(row=5,column=8)

        self.lblser= Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="Service Charge:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lblser.grid(row=6,column=7)
        self.txtser= Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Service_Charge ,width=14,bd=6,bg="light grey" ,justify='right')
        self.txtser.grid(row=6,column=8)

        self.lbltax = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="      Indiana Tax:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lbltax.grid(row=7,column=7)
        self.txttax = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Tax, bd=6,width=14,bg="light grey" ,justify='right')
        self.txttax.grid(row=7,column=8)

        self.lbltot = Label(self.admainf2,pady=2, font=( 'aria' ,16, 'bold' ),text="                 Total:",bg="#f2e8b8",fg="#7769ad",bd=6,anchor='w')
        self.lbltot.grid(row=8,column=7)
        self.txttot = Entry(self.admainf2,font=('ariel' ,16,'bold'), textvariable=self.Total, bd=6,width=14,bg="light grey" ,justify='right')
        self.txttot.grid(row=8,column=8)

        self.btnTotal=Button(self.admainf2,pady=2,bd=6,fg="black",font=('ariel' ,16,'bold'),width=6, text="TOTAL", bg="light grey",command=lambda:Calculations(self))
        self.btnTotal.place(x=1160,y=440)

        self.btnreset=Button(self.admainf2,pady=2,bd=6 ,fg="black",font=('ariel' ,16,'bold'),width=6, text="RESET", bg="light grey",command=lambda:reset(self))
        self.btnreset.place(x=970,y=500)

        self.btnprice=Button(self.admainf2,pady=2,bd=6 ,fg="black",font=('ariel' ,16,'bold'),width=6, text="PRICES", bg="light grey",command=lambda:price(self))
        self.btnprice.place(x=970,y=440)

        self.btnpay=Button(self.admainf2,pady=2, bd=6 ,fg="black",font=('ariel' ,16,'bold'),width=6, text="PAY", bg="light grey",command=lambda:self.main())
        self.btnpay.place(x=1160,y=500)

        #Exit button for application
        self.button_3 =Button(self.mainWindow,text="Exit Application",command=self.mainWindow.destroy, fg="red", font=("Arial",32, 'bold'))
        self.button_3.place(x=100,y=600, width= 380, height= 100)

        self.mainWindow.mainloop()
##End fields on mainWindowScreen

x=kirbysPizza()
x.main()